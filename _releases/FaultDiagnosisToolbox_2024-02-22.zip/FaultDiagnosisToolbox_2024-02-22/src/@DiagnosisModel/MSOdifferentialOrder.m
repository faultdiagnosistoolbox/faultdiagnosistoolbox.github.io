function [eqOrder,zIdx,zOrder,fIdx,fOrder] = MSOdifferentialOrder(model, mso)
% MSOdifferentialOrder For a given MSO set, determine the number of
%                      required differentiations of each equation, each
%                      known variable in the model to obtain an ARR.
%
%  [] = model.MSOdifferentialOrder( mso )
%
%  The options are given as key/value pairs as
%
%  Inputs:
%    model              A diagnosis model object.
%    mso                An array of equation indices in model that is an 
%                       MSO set.
%
%  Outputs:
%    eqOrder            Array of the required number of differentiations of
%                       each equation in the mso needed to derive an ARR.
%                       
%    zIdx               The known variables included in the mso given as an
%                       array of indices of model.z
% 
%    zOrder             Array of the highest order of derivatives of each
%                       known variable included in an ARR based on the
%                       equations in mso.
%
%    fIdx               The fault variables included in the mso given as an
%                       array of indices of model.f
% 
%    fOrder             Array of the lowest order of derivatives of each
%                       fault variable included in an ARR based on the
%                       equations in mso. The lowest order of derivative is
%                       more related to fault detection performance than
%                       the highest order of derivative.
%
%
% Copyright Mattias Krysander, 2024
% Distributed under the MIT License.
% (See accompanying file LICENSE or copy at
%  http://opensource.org/licenses/MIT)

% Extract submatrices for the mso
xIdx = find(any(model.X(mso,:),1));
zIdx = find(any(model.Z(mso,:),1));
fIdx = find(any(model.F(mso,:),1));

X = model.X(mso,xIdx);
Z = model.Z(mso,zIdx);
F = model.F(mso,fIdx);

% Write the system on the matrix form
%  x1' x1  x2
%  A   B   C

[rX1,cX1] = find(X==2);
A = X(:,cX1)==2;               % first order derivatives
B = X(:,cX1)==1|X(:,cX1)==3;   % state variables

nx = numel(xIdx);
cX2 = setdiff([1:nx],cX1);
C = X(:,cX2);                  % algebraic variables

AB = or(A,B);  

ns = numel(cX1);          % number of states
nalg = nx-ns;             % number of algebraic unknowns
neq = size(X,1);          % number of equations

% Consider derivatives as separate variables, thus the system of equations
% as purely algerbraic. Add differentiated equations until the algebraic
% systems contains an overdetermined part.

Mmax = [A B C]; % The set of most differentiated equations
Mall = Mmax;    % The set of all equations 

% Compute the overdetermined part
dm=GetDMParts(Mall);

i = 0; % highest derivative orders of equations in Mall

while isempty(dm.Mp.row) & i < ns % Differentiate at most ns times   
    i = i+1;

    % Insert new columns corresponding to new derivatives
    Mall = [zeros(size(Mall,1),ns) Mall(:,[1:(i+1)*ns])...
            zeros(size(Mall,1),nalg) Mall(:,[(i+1)*ns+1:end])]; 

    % Differentiate the most differentiated equations once more
    Mmax = [Mmax(:,[1:ns]) AB Mmax(:,[ns+1:ns*(i+1)]) ...
        C Mmax(:,[ns*(i+1)+1:end])];

    % Put together the old with the new equations.
    Mall = [Mall;Mmax];

    % Compute the overdetermined part
    dm=GetDMParts(Mall);
end

overdeteq = dm.Mp.row;  % overdetermined equations in Mall

eqOrder = zeros(1,neq);
for i = 1:ceil(max(overdeteq)/neq)
    for j = 1:neq
        [a,~]=ismember([j:neq:max(overdeteq)],overdeteq);
        if any(a)
            eqOrder(j) = find(a,1,'last')-1;
            eqLowOrder(j) = find(a,1,'first')-1;
        else
            eqOrder(j) = -1;
            eqLowOrder(j) = -1;
        end
    end
end
[Zineq,~]=find(Z);
zOrder = eqOrder(Zineq);
[Fineq,~]=find(F);
fOrder = eqLowOrder(Fineq);
