function d=DiffConstraint(dvar, ivar)
  d = {dvar,ivar,'diff'};
end