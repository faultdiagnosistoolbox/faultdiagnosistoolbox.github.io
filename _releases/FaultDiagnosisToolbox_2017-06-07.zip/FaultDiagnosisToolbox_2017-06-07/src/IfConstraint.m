function d=IfConstraint(condition, e1, e2)
  d = {condition,e1, e2, 'if'};
end