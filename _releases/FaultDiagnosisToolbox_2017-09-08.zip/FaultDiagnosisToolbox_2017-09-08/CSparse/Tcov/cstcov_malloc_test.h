#include "cs.h"
#ifndef EXTERN
#define EXTERN extern
#endif
EXTERN csi malloc_count ;
